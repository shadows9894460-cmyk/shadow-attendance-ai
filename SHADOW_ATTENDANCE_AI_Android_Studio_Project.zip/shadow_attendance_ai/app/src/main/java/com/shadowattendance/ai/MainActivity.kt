package com.shadowattendance.ai

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var prefs: android.content.SharedPreferences
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private val purple = Color.rgb(139, 124, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(178, 181, 205)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("attendance", MODE_PRIVATE)
        tts = TextToSpeech(this, this)
        createChannel()
        requestNotificationPermission()
        ReminderScheduler.schedule(this)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 34, 24, 24)
            setBackgroundColor(Color.rgb(9, 11, 22))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = TextView(this).apply {
            text = "SHADOW\nATTENDANCE AI"
            textSize = 29f; setTextColor(white); gravity = Gravity.CENTER
            setPadding(8, 22, 8, 8); letterSpacing = .08f
        }
        content.addView(brand, match())
        content.addView(label("YOUR PERSONAL ATTENDANCE ASSISTANT", 12f, purple, true))
        content.addView(label("Daily reminder  •  11:00 AM\nSunday: Holiday", 16f, muted, false).apply { gravity = Gravity.CENTER; setPadding(8, 18, 8, 22) })
        status = label("Today's status: ${todayStatus()}", 20f, white, true)
        status.gravity = Gravity.CENTER
        status.setPadding(12, 22, 12, 22)
        status.setBackgroundColor(Color.rgb(24, 27, 48))
        content.addView(status, match())
        content.addView(space())
        content.addView(actionButton("MARK PRESENT") { saveStatus("Present") })
        content.addView(spaceSmall())
        content.addView(actionButton("MARK ABSENT") { saveStatus("Absent") })
        content.addView(spaceSmall())
        content.addView(actionButton("TEST VOICE ALERT") {
            val result = tts?.speak("Sanjay, attendance poda marakkadhe. Please mark your attendance.", TextToSpeech.QUEUE_FLUSH, null, "shadow_voice")
            if (result == TextToSpeech.ERROR) Toast.makeText(this, "Voice is not available on this device", Toast.LENGTH_LONG).show()
        })
        content.addView(spaceSmall())
        content.addView(actionButton("VIEW ATTENDANCE HISTORY") { showHistory() })
        content.addView(spaceSmall())
        content.addView(label("Reminder is scheduled for 11:00 AM, Monday to Saturday. Allow notifications in Android settings. Voice uses the speech voice installed on your phone; choose a female voice in Text-to-speech settings if available.", 13f, muted, false).apply { setPadding(4, 18, 4, 20) })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun saveStatus(value: String) {
        val key = dateKey()
        prefs.edit().putString(key, value).apply()
        status.text = "Today's status: $value"
        Toast.makeText(this, "Attendance saved: $value", Toast.LENGTH_SHORT).show()
    }
    private fun todayStatus() = prefs.getString(dateKey(), "Not marked") ?: "Not marked"
    private fun dateKey() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun showHistory() {
        val entries = prefs.all.filterKeys { it.matches(Regex("\\d{4}-\\d{2}-\\d{2}")) }.toSortedMap(compareByDescending { it })
        val message = if (entries.isEmpty()) "No attendance records yet." else entries.entries.joinToString("\n") { "${it.key}: ${it.value}" }
        AlertDialog.Builder(this).setTitle("Attendance History").setMessage(message).setPositiveButton("CLOSE", null).show()
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("attendance_reminder", "Attendance reminders", NotificationManager.IMPORTANCE_HIGH).apply { description = "Daily attendance reminder" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale("en", "IN")
            // The device's installed TTS voice is used; voice gender availability varies by device.
        }
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }
    private fun actionButton(textValue: String, click: () -> Unit) = Button(this).apply {
        text = textValue; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(48, 43, 91)))
        textSize = 14f; setOnClickListener { click() }
    }
    private fun match() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun space() = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, 22) }
    private fun spaceSmall() = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, 8) }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val calendar = Calendar.getInstance()
        if (calendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(context, 1, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(context, "attendance_reminder")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("SHADOW ATTENDANCE AI")
            .setContentText("Sanjay, attendance poda marakkadhe! Mark your attendance.")
            .setAutoCancel(true).setContentIntent(open).build()
        manager.notify(1101, notification)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) { ReminderScheduler.schedule(context) }
}

object ReminderScheduler {
    fun schedule(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, 1100, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 11); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            while (get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) add(Calendar.DAY_OF_YEAR, 1)
        }
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, next.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
    }
}
